// Framework: Java
// Technology stack: N/A

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Scanner;
import java.util.HashSet;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Collections;
class obj_answer {

    public static int longestConsecutive(int[] nums) {
        int ans = 0;
        int n = nums.length;
        Set<Integer> mSet = new HashSet<>();
        List<Integer> numsX = new ArrayList<>();

        if(n == 0){
            return 0;
        }

        for(int t = 0; t < nums.length; t++){ // Filtering
            if(mSet.contains(nums[t])){
                continue;
            }
            numsX.add(nums[t]);
            mSet.add(nums[t]);
        }

        n = numsX.size(); // Filtered data
        int[] head = new int[n+1];

        // Sort in ascending order
        Collections.sort(numsX);

        initUnionSet(n, head, numsX);

        for(int i = 1; i < n; i++){
            if(numsX.get(i-1) + 1 == numsX.get(i)){ // Consecutive
                unionSet(head, i-1, i); // Merge
            }
        }

        Map<Integer, Integer> mMap = new HashMap<>();

        for(int i = 1; i <= numsX.size(); i++){
            mMap.put(head[i], mMap.getOrDefault(head[i], 0) + 1);
            ans = Math.max(ans, mMap.get(head[i]));
        }

        return ans;
    }

    private static void initUnionSet(int n, int[] head, List<Integer> numsX) {
        for(int i = 0; i < n; i++){
            head[i] = i;
            numsX.set(i, numsX.get(i) < 0 ? numsX.get(i) + Math.abs(numsX.get(i)) : numsX.get(i)); // Handle negative numbers technique
        }
    }

    private static int find(int[] head, int x) {
        return x == head[x] ? x : (head[x] = find(head, head[x]));
    }

    private static void unionSet(int[] head, int i, int j) {
        int x = find(head, i);
        int y = find(head, j);

        if(x > y){ // Smaller node becomes parent node
            head[x] = y;
        } else {
            head[y] = x;
        }
    }
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n=scanner.nextInt();
		int []nums=new int[n];
		for(int i=0;i<n;i++){
		   nums[i]=scanner.nextInt();
		}
		int ansx=longestConsecutive(nums);
		System.out.println(ansx);
    }
}