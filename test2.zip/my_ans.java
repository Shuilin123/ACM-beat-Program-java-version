import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
class my_ans {
    //Dynamic Programming by Shuilin
    public static int longestConsecutive(List<Integer> nums) {
        Collections.sort(nums);
        //Define dp
        List<Integer> dp = new ArrayList<>(nums.size() + 1);
        /*
         The longest consecutive subsequence length of the first i numbers is dp[i]
        */
        if(nums.size() == 0){
            return 0;
        }else if(nums.size() == 1){
            return 1;
        }
        dp.add(0, 1);
        /*
          The longest consecutive subsequence length of the first i numbers is dp[i]
          dp[i] = dp[j] + 1 if num[j] + 1 == num[i] && j <= i
        */
        //[0,3,7,2,5,8,4,6,0,1,-1,-2,-3,-4,-5,3124,41341,434141]
        int ans = 0;
        for(int i = 1; i < nums.size(); i++){
            for(int j = i - 1; j >= 0; j--){
                if(nums.get(j) + 1 == nums.get(i)){
                    dp.add(i, dp.get(j) + 1);
                    ans = dp.get(i); //Save the last result
                    continue;
                }
            }
        }
        return ans;
    }
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n=scanner.nextInt();
        List<Integer> nums=new ArrayList<>(n);
        for(int i=0;i<n;i++){
            nums.add(scanner.nextInt());
        }
        int ansx=longestConsecutive(nums);
        System.out.println(ansx);
    }
}