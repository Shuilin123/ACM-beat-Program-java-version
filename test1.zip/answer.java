import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Scanner;
class answer {
    // Two Pointers by Shuilin
    public static  List<List<Integer>> fourSum(int[] nums, int target) {
        List<List<Integer>> ans = new ArrayList<>();
        int left = 0, right = 0, len = nums.length - 1;
        Set<List<Integer>> mSet = new HashSet<>();
        Arrays.sort(nums);
        for (int i = 0; i < len; i++) {
            for (int j = i + 1; j < len; j++) {
                left = j + 1;
                right = len; //[left,right]中查找合适的left,right
                while (left < right) {//双指针搜索满足条件的nums[left]与nums[right]
                    //注意内存泄漏问题
                    long sum = (long) nums[i] + nums[j] + nums[left] + nums[right];
                    if (sum == target) {
                        List<Integer> temp = new ArrayList<>();//保存结果
                        temp.add(nums[i]);
                        temp.add(nums[j]);
                        temp.add(nums[left]);
                        temp.add(nums[right]);
                        if (!mSet.contains(temp)) {//去重
                            mSet.add(temp);
                            ans.add(temp);
                        }
                        left++;
                        right--;//缩小搜索范围
                    } else if (sum < target) {
                        left++;//当前值估小了 移动左边界
                    } else {
                        right--;//当前值估大了 移动右边界
                    }
                }
            }
        }
        return ans;
    }
	public static void main(String[] args){
		 Scanner scanner = new Scanner(System.in);
		 int target=scanner.nextInt();
		 int n=scanner.nextInt();
		 int []nums=new int[n];
		 for(int i=0;i<n;i++){
		    nums[i]=scanner.nextInt();
		 }
		 List<List<Integer>> ans=fourSum(nums, target);
		 for(List<Integer> table:ans){
		    for(Integer i:table){
				System.out.print(i);
				System.out.print(" ");
				
			}
			System.out.println("");
		 }
	}
}