import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
class my {
    // by 水林
    public static List<List<Integer>> fourSum(int[] nums, int target) {
        List<List<Integer>> ans = new ArrayList<>();
        int left = 0, right = 0, len = nums.length - 1;
        Set<List<Integer>> mSet = new HashSet<>();
        Arrays.sort(nums);
        for (int i = 0; i < len; i++) {
            if (nums[i] > target) {
                break;
            }
            for (int j = i + 1; j < len; j++) {
                if (nums[i] + nums[j] > target) {
                    break;
                }
                left = j + 1;
                right = len;
                while (left < right) {
                    if (nums[i] + nums[j] + nums[left] + nums[right] == target) {
                        List<Integer> temp = new ArrayList<>();
                        temp.add(nums[i]);
                        temp.add(nums[j]);
                        temp.add(nums[left]);
                        temp.add(nums[right]);
                        if (!mSet.contains(temp)) {
                            mSet.add(temp);
                            ans.add(temp);
                        }
                        left++;
                        right--;
                    } else if (nums[i] + nums[j] + nums[left] + nums[right] < target) {
                        left++;
                    } else {
                        right--;
                    }
                }
            }
        }
        return ans;
    }
	public static void main(String[] args){
		 Scanner scanner = new Scanner(System.in);
		 int target=scanner.nextInt();
		 int n=scanner.nextInt();
		 int []nums=new int[n];
		 for(int i=0;i<n;i++){
		    nums[i]=scanner.nextInt();
		 }
		 List<List<Integer>> ans=fourSum(nums, target);
		 for(List<Integer> table:ans){
		    for(Integer i:table){
				System.out.print(i);
				System.out.print(" ");
				
			}
			System.out.println("");
		 }
	}
}