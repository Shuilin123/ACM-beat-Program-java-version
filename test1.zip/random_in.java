import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
class random_in {
    // Two Pointers by Shuilin
    public static int rand(int a,int b){
        return (int)(a+Math.random()*(b-a+1));
    }
    public static void main(String[] args) {
        int a=-1000000000,b=1000000000;
        int target=rand(a,b);
        int n=rand(1,200);
        int []data=new int[n];
        for(int i=0;i<n;i++){
            data[i]=rand(a,b);
        }
        try {
            System.setOut(new PrintStream(new FileOutputStream("data.in")));

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            return;
        }
        System.out.print(target);
        System.out.print(" ");
		System.out.print(n);
        System.out.print(" ");
        for(int i=0;i<n;i++){
            System.out.print(" ");
            System.out.print(data[i]);
        }
        System.out.println("");
    }
}
